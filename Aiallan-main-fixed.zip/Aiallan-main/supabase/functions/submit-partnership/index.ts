import nodemailer from 'npm:nodemailer@7.0.6';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
};

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  });

const b64u = (bytes: Uint8Array) => {
  let s = '';
  for (const b of bytes) s += String.fromCharCode(b);
  return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '');
};
const unb64u = (s: string) => {
  const x = s.replace(/-/g, '+').replace(/_/g, '/');
  return Uint8Array.from(atob(x + '='.repeat((4 - x.length % 4) % 4)), c => c.charCodeAt(0));
};
const textBytes = (s: string) => new TextEncoder().encode(s);

async function hmac(value: string) {
  const secret = Deno.env.get('CONTACT_HMAC_SECRET');
  if (!secret) throw new Error('CONTACT_HMAC_SECRET is not configured.');
  const key = await crypto.subtle.importKey('raw', textBytes(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  return new Uint8Array(await crypto.subtle.sign('HMAC', key, textBytes(value)));
}

async function makeVerificationToken(email: string, code: string) {
  const payload = { kind: 'code', email, codeHash: Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', textBytes(code)))), exp: Date.now() + 10 * 60 * 1000 };
  const body = b64u(textBytes(JSON.stringify(payload)));
  return `${body}.${b64u(await hmac(body))}`;
}

async function verifyToken(token: string, email: string, code: string) {
  const [body, sig] = String(token || '').split('.');
  if (!body || !sig) return false;
  const expected = await hmac(body);
  const actual = unb64u(sig);
  if (expected.length !== actual.length) return false;
  let diff = 0;
  for (let i = 0; i < expected.length; i++) diff |= expected[i] ^ actual[i];
  if (diff !== 0) return false;
  const payload = JSON.parse(new TextDecoder().decode(unb64u(body)));
  if (payload.kind !== 'code' || payload.email !== email || Number(payload.exp) < Date.now()) return false;
  const digest = Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', textBytes(code))));
  return JSON.stringify(digest) === JSON.stringify(payload.codeHash);
}

function mailer() {
  const user = Deno.env.get('GMAIL_SMTP_USER');
  const pass = Deno.env.get('GMAIL_SMTP_PASS');
  if (!user || !pass) throw new Error('Gmail SMTP function secrets are not configured.');
  return nodemailer.createTransport({ host: 'smtp.gmail.com', port: 465, secure: true, auth: { user, pass } });
}

function clean(s: unknown, max = 12000) {
  return String(s ?? '').trim().slice(0, max);
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  if (req.method === 'GET') return json({ ok: true, service: 'submit-partnership' });

  try {
    const form = await req.formData();
    const action = clean(form.get('action'), 40);
    const email = clean(form.get('email'), 160).toLowerCase();
    if (!/^\S+@gmail\.com$/i.test(email)) return json({ error: 'Enter a valid Gmail address.' }, 400);

    if (action === 'send_code') {
      const code = String(Math.floor(100000 + Math.random() * 900000));
      const token = await makeVerificationToken(email, code);
      const transport = mailer();
      await transport.sendMail({
        from: Deno.env.get('GMAIL_SMTP_USER'),
        to: email,
        subject: 'Your Aiallan verification code',
        text: `Your Aiallan verification code is ${code}. It expires in 10 minutes. If you did not request this code, ignore this email.`,
      });
      return json({ ok: true, sent: true, verification_token: token });
    }

    if (action === 'verify_code') {
      const code = clean(form.get('code'), 6);
      const token = clean(form.get('verification_token'), 4000);
      // The browser receives the signed challenge after send_code. Accept it here
      // and issue a short-lived verified session token for the message step.
      if (!token) return json({ error: 'Verification session expired. Send a new code.' }, 400);
      const valid = await verifyToken(token, email, code);
      if (!valid) return json({ error: 'Invalid or expired verification code.' }, 400);
      const verified = await makeVerificationToken(email, 'verified:' + crypto.randomUUID());
      const verifiedParts = verified.split('.');
      const verifiedPayload = JSON.parse(new TextDecoder().decode(unb64u(verifiedParts[0])));
      verifiedPayload.kind = 'verified';
      const verifiedBody = b64u(textBytes(JSON.stringify(verifiedPayload)));
      const verifiedToken = `${verifiedBody}.${b64u(await hmac(verifiedBody))}`;
      return json({ ok: true, verified: true, verification_token: verified });
    }

    if (action === 'send_message') {
      const token = clean(form.get('verification_token'), 4000);
      const purpose = clean(form.get('purpose'), 120);
      const message = clean(form.get('message'), 20000);
      if (!token || !message) return json({ error: 'Verification and message are required.' }, 400);

      // For the message step, the token contains a verified challenge. It is
      // intentionally short-lived; the actual sender address is taken from it.
      const [body, sig] = token.split('.');
      if (!body || !sig) return json({ error: 'Invalid verification session.' }, 400);
      const expected = await hmac(body);
      const actual = unb64u(sig);
      if (expected.length !== actual.length) return json({ error: 'Invalid verification session.' }, 400);
      let diff = 0; for (let i = 0; i < expected.length; i++) diff |= expected[i] ^ actual[i];
      if (diff !== 0) return json({ error: 'Invalid verification session.' }, 400);
      const verifiedPayload = JSON.parse(new TextDecoder().decode(unb64u(body)));
      if (verifiedPayload.kind !== 'verified' || verifiedPayload.email !== email || !String(verifiedPayload.email || '').endsWith('@gmail.com') || Number(verifiedPayload.exp) < Date.now()) return json({ error: 'Verification session expired.' }, 400);

      const attachments: { filename: string; content: Uint8Array; contentType?: string }[] = [];
      for (const [key, value] of form.entries()) {
        if (key !== 'attachments' || !(value instanceof File)) continue;
        if (value.size > 8 * 1024 * 1024) return json({ error: 'Each attachment must be 8 MB or smaller.' }, 400);
        attachments.push({ filename: value.name || 'attachment', content: new Uint8Array(await value.arrayBuffer()), contentType: value.type || undefined });
        if (attachments.length > 8) return json({ error: 'You can attach up to 8 files per inquiry.' }, 400);
      }

      const transport = mailer();
      await transport.sendMail({
        from: Deno.env.get('GMAIL_SMTP_USER'),
        to: Deno.env.get('GMAIL_SMTP_USER'),
        replyTo: verifiedPayload.email,
        subject: `[Aiallan] ${purpose || 'Professional Inquiry'}`,
        text: `From Gmail: ${verifiedPayload.email}\nPurpose: ${purpose}\n\n${message}`,
        attachments,
      });
      return json({ ok: true, sent: true });
    }

    return json({ error: 'Unknown action.' }, 400);
  } catch (e) {
    console.error('[submit-partnership]', e);
    return json({ error: e instanceof Error ? e.message : 'Email service failed.' }, 500);
  }
});
