/**
 * AIALAN image CDN proxy
 *
 * GitHub Pages remains the website host.
 * The existing public Supabase Storage bucket remains the image origin.
 * Cloudflare caches public assets at the edge.
 */
const SUPABASE_ORIGIN = 'https://tqtmssdjfptmbvjtxien.supabase.co';
const BUCKET = 'site-assets';
const CACHE_TTL = 31536000;

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);

    if (request.method !== 'GET' && request.method !== 'HEAD') {
      return new Response('Method Not Allowed', {
        status: 405,
        headers: { 'Allow': 'GET, HEAD' }
      });
    }

    let assetPath = url.pathname.replace(/^\/+/, '');
    if (assetPath.startsWith('site-assets/')) {
      assetPath = assetPath.slice('site-assets/'.length);
    }

    // Only allow paths inside the existing public site-assets bucket.
    if (!assetPath || assetPath.includes('..')) {
      return new Response('Not Found', { status: 404 });
    }

    const originUrl =
      `${SUPABASE_ORIGIN}/storage/v1/object/public/${BUCKET}/${assetPath}${url.search}`;

    const cache = caches.default;
    const cacheKey = new Request(url.toString(), { method: request.method });
    let response = await cache.match(cacheKey);

    if (!response) {
      const originResponse = await fetch(originUrl, {
        method: request.method,
        headers: { 'Accept': request.headers.get('Accept') || '*/*' }
      });

      if (!originResponse.ok) {
        return new Response(originResponse.body, {
          status: originResponse.status,
          statusText: originResponse.statusText,
          headers: originResponse.headers
        });
      }

      const headers = new Headers(originResponse.headers);
      headers.set('Cache-Control', `public, max-age=${CACHE_TTL}, immutable`);
      headers.set('CDN-Cache-Control', `public, max-age=${CACHE_TTL}, immutable`);
      headers.set('Access-Control-Allow-Origin', '*');
      headers.delete('Set-Cookie');

      response = new Response(originResponse.body, {
        status: originResponse.status,
        statusText: originResponse.statusText,
        headers
      });

      ctx.waitUntil(cache.put(cacheKey, response.clone()));
    }

    return response;
  }
};
